"""
URL configuration for recipe_api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from rest_framework.views import APIView
from recipe import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('recipe',views.RecipeCreate.as_view()),
    path('recipelist',views.RecipeList.as_view()),
    path('recipeid/<int:i>',views.Recipeid.as_view()),
    path('recipefull/<int:i>',views.RecipeFullupdate.as_view()),
    path('recipepartial/<int:i>',views.RecipePartialupdate.as_view()),
    path('recipedelete/<int:i>',views.Recipedelete.as_view()),
]
